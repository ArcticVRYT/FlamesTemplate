﻿using BepInEx;
using Flame.sidfisdfiu;
using FlameMenuOnTop.Backend;
using FlameMenuOnTop.UI;
using HarmonyLib;
using Loading;
using System;
using System.Diagnostics;
using UnityEngine;
using static FlameMenuOnTop.Plugin;
using Object = UnityEngine.Object;

namespace FlameMenuOnTop
{
    [BepInPlugin(Name, GUID, Version)]
    public class Plugin : BaseUnityPlugin
    {
        public const string Name = "FlameMenuOnTop";
        public const string GUID = "org.FlameMenuOnTopfun";
        public const string Version = "1.0";

        private bool patchedHarmony = false;
        private static GameObject Gameobject;
        [System.Serializable]
        public class LoginData
        {
            public string license;

        }
        void Awake()
        {
            if (!patchedHarmony && Loads.loaded == false)
            {
                Harmony harmony = new Harmony(GUID);
                harmony.PatchAll();
                patchedHarmony = true;
                Loads.loaded = true;

            }
        }
    }
    [HarmonyPatch(typeof(GorillaLocomotion.Player), "FixedUpdate")]
    internal class UpdatePatch
    {
        private static bool alreadyInit;
        public static GameObject Gameobject;

        static void Postfix()
        {
           
            if (!alreadyInit)
            {
                alreadyInit = true;
                Gameobject = new GameObject();
                Gameobject.AddComponent<Plugin>();
                Gameobject.AddComponent<TheMenu>();
                Gameobject.AddComponent<Rs>();
                Gameobject.AddComponent<Mods>();
                Gameobject.AddComponent<gp>();
                Gameobject.AddComponent<GTAG_NotificationLib.NotifiLib>();
                Mods.Load();
                Object.DontDestroyOnLoad(Gameobject);
            }
        }
    }
}
